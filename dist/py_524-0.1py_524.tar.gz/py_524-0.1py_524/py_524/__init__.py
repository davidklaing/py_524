from py_524 import standard_deviation
