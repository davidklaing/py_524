from distutils.core import setup

setup(
    name='py_524',
    version='0.1py_524',
    packages=['py_524'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
